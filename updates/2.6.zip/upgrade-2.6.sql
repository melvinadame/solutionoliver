ALTER TABLE `clients` ADD `created_by` INT(11) NOT NULL AFTER `owner_id`;#

ALTER TABLE `tasks` ADD `status_changed_at` DATETIME NULL DEFAULT NULL AFTER `ticket_id`;#

INSERT INTO `payment_methods` (`id`, `title`, `type`, `description`, `online_payable`, `available_on_invoice`, `minimum_payment_amount`, `settings`, `deleted`) VALUES (NULL, 'Paytm', 'paytm', 'Paytm online payments', '1', '0', '0', '', '0');#

ALTER TABLE `items` ADD `files` MEDIUMTEXT NOT NULL AFTER `rate`, ADD `show_in_client_portal` TINYINT(1) NOT NULL DEFAULT '0' AFTER `files`, ADD `sort` INT NOT NULL DEFAULT '0' AFTER `show_in_client_portal`;#


CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `note` mediumtext COLLATE utf8_unicode_ci DEFAULT NULL,
  `status_id` int(11) NOT NULL,
  `tax_id` int(11) NOT NULL DEFAULT 0,
  `tax_id2` int(11) NOT NULL DEFAULT 0,
  `discount_amount` double NOT NULL,
  `discount_amount_type` enum('percentage','fixed_amount') COLLATE utf8_unicode_ci NOT NULL,
  `discount_type` enum('before_tax','after_tax') COLLATE utf8_unicode_ci NOT NULL,
  `created_by` int(11) NOT NULL DEFAULT 0,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
   PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `quantity` double NOT NULL,
  `unit_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `rate` double NOT NULL,
  `total` double NOT NULL,
  `order_id` int(11) NOT NULL,
  `created_by` INT(11) NOT NULL,
  `item_id` INT(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

CREATE TABLE IF NOT EXISTS `order_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `sort` int(11) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;#

INSERT INTO `order_status` (`id`, `title`, `color`, `sort`, `deleted`) VALUES 
('1', 'New', '#f1c40f', '0', '0'), 
('2', 'Processing', '#29c2c2', '1', '0'),  
('3', 'Confirmed', '#83c340', '2', '0');#


ALTER TABLE `custom_fields` ADD `show_in_order` TINYINT(1) NOT NULL DEFAULT '0' AFTER `show_in_estimate`;#

ALTER TABLE `notifications` ADD `order_id` INT(11) NOT NULL AFTER `estimate_id`;#

INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `enable_slack`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'new_order_received', 'order', '0', '0', '0', '', '', '', '1', '0');#

INSERT INTO `notification_settings` (`id`, `event`, `category`, `enable_email`, `enable_web`, `enable_slack`, `notify_to_team`, `notify_to_team_members`, `notify_to_terms`, `sort`, `deleted`) VALUES (NULL, 'order_status_updated', 'order', '0', '0', '0', '', '', '', '2', '0');#

INSERT INTO `email_templates` (`id`, `template_name`, `email_subject`, `default_message`, `custom_message`, `deleted`) VALUES (NULL, 'new_order_received', 'New order received', '<div style="background-color: #eeeeef; padding: 50px 0; "> <div style="max-width:640px; margin:0 auto; "> <div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h1>ORDER #{ORDER_ID}</h1></div> <div style="padding: 20px; background-color: rgb(255, 255, 255);">  <p style=""><span style="color: rgb(85, 85, 85); font-size: 14px;">A new order has been received from&nbsp;</span><span style="color: rgb(85, 85, 85); font-size: 14px;">{CONTACT_FIRST_NAME} and is attached here.</span><br></p><p style=""><br></p><p style=""><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;"><a style="background-color: #00b393; padding: 10px 15px; color: #ffffff;" href="{ORDER_URL}" target="_blank">Show Order</a></span></p><p style=""><br></p>  </div> </div></div>', '', '0');#

INSERT INTO `email_templates` (`id`, `template_name`, `email_subject`, `default_message`, `custom_message`, `deleted`) VALUES (NULL, 'order_status_updated', 'Order status updated', '<div style="background-color: #eeeeef; padding: 50px 0; "> <div style="max-width:640px; margin:0 auto; "> <div style="color: #fff; text-align: center; background-color:#33333e; padding: 30px; border-top-left-radius: 3px; border-top-right-radius: 3px; margin: 0;"><h1>ORDER #{ORDER_ID}</h1></div> <div style="padding: 20px; background-color: rgb(255, 255, 255);">  <p><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;">Hello {CONTACT_FIRST_NAME},</span><br></p><p><span style="font-size: 14px; line-height: 20px;">Thank you for your business cooperation.</span><br></p><p><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;">Your order&nbsp;</span><font color="#555555"><span style="font-size: 14px;">has been updated&nbsp;</span></font><span style="color: rgb(85, 85, 85); font-size: 14px;">and is attached here.</span></p><p style=""><br></p><p style=""><span style="color: rgb(85, 85, 85); font-size: 14px; line-height: 20px;"><a style="background-color: #00b393; padding: 10px 15px; color: #ffffff;" href="{ORDER_URL}" target="_blank">Show Order</a></span></p><p style=""><br></p>  </div> </div></div>', '', '0');#
