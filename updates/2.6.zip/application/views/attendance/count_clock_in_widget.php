<div class="panel panel-info">
    <a href="<?php echo get_uri('attendance/index/members_clocked_in'); ?>" class="white-link">
        <div class="panel-body">
            <div class="widget-icon">
                <i class="fa fa-clock-o"></i>
            </div>
            <div class="widget-details">
                <h1><?php echo $members_clocked_in; ?></h1>
                <?php echo lang("members_clocked_in"); ?>
            </div>
        </div>
    </a>
</div>