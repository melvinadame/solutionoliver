<table id="yearly-order-table" class="display" cellspacing="0" width="100%">   
</table>
<script type="text/javascript">
    $(document).ready(function () {
        loadOrdersTable("#yearly-order-table", "yearly");
    });
</script>